
from .BinPackingFitness import BinPackingFitness
from .BullseyeFitness import BullseyeFitness
from .MatchFitness import MatchFitness
from .SudokuFitness import SudokuFitness

from .GPFitness import GPFitness
