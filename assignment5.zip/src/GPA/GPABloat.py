from .GPA import GPA

class GPABloat:
    def optimize(self, ind: GPA | None) -> GPA | None:
        return ind
