

print(5 == None)

